<!-- Modal -->
<div id="delete_facture_client" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Supprimer</h4>
      </div>
      <div class="modal-body">
        <h2>Vous voulez vraiment supprimer?</h2>
      </div>
      <div class="modal-footer">
       <a href="" class="btn btn-danger modal_delete_link">Supprimer</a>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>


